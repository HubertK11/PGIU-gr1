# Pro_hinduski_sprint
Dwa tygodnie przed i jest fajnie
